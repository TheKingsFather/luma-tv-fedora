# Luma TV for Fedora

Native Qt desktop edition of Luma, with the teal/violet glass theme, Stremio QR pairing and mpv video playback. Version 0.1.1.

## Open

Search **Luma TV** in the Fedora applications menu, run `luma-tv`, or run `./launch.sh` from this folder. Scan the QR code with your phone and connect on Stremio's official linking page. You can also enter the displayed code at `link.stremio.com`. The desktop uses its own connection; it does not extract the Android app's credentials.

The **Explore the interface** button opens public Cinemeta catalogs before connecting. Once connected, the app imports your installed Stremio add-ons and library. Manage add-ons in Stremio on your phone, then use **Settings → Refresh Stremio** here.

## Features

- Native resizable Qt window, artwork-backed glass panels, poster rows, mouse and keyboard navigation.
- Home, Movies, Series, Live catalogs, search, catalog pagination, library, details and season/episode selection.
- Direct stream discovery, provider request headers, source selection and failover.
- Playback in an owned mpv window, with pause, seek, audio/subtitle selection, add-on subtitle downloads, next episode and sleep timer controls in Luma.
- Continue watching and watch-state sync. Offline changes are saved locally and retried on refresh or subsequent writes.
- Encrypted account/cache file. Its encryption key is stored in Fedora's Secret Service keyring. The app never writes an unencrypted Stremio auth key to disk or passes stream URLs in mpv's command-line arguments.

This is an initial desktop port. The video opens in mpv's separate window rather than an embedded glass player. It supports direct HTTP(S) streams, not raw torrent/infoHash-only sources. DRM setup and Alder's native FFmpeg/chapter extensions are not included. Account import and authenticated cloud updates still require the owner to finish QR pairing.

## Controls

- Luma: **F11** fullscreen, **Ctrl+F** search, **Escape** back.
- mpv video window: **Space** pause, **←/→** seek, **F** fullscreen, **J** subtitles, **#** audio track.
- Closing Luma also stops its owned player. Settings → Disconnect removes this desktop's saved account data.

## Dependencies on another Fedora machine

```bash
sudo dnf install python3-pyqt6-base python3-requests python3-cryptography libsecret mpv
./launch.sh
```

To register the applications-menu entry after extracting the source on another machine, run `python3 install.py` once from the extracted folder. Keep the folder in place afterward; the launcher points to it.

Your desktop must provide a Secret Service keyring (GNOME Keyring or an equivalent). The launcher uses the system Python and the installed Fedora packages; it does not modify other Python apps or environments.

Data: `$XDG_DATA_HOME/luma-desktop/session.enc` (normally `~/.local/share/luma-desktop/session.enc`). Preferences: Qt's `Luma/Desktop` settings. The mpv IPC socket is created inside a private temporary directory and removed on stop. Subtitle downloads use separate requests without video-provider headers.

## Validation

```bash
QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests -v
QT_QPA_PLATFORM=offscreen ./launch.sh --preview --smoke
```

The 21 checks cover protocol capability rules, URL encoding, future episodes, metadata merging, direct-stream filtering, encryption/file permissions, resume behavior, offline sync queues, live Stremio link/pending state, public catalogs, native browse/details UI, and local mpv playback/pause/seek over private IPC. The desktop keyring was also verified with a temporary test record, which was removed afterward. See `artifacts/tests.log` and the UI screenshots.

Live API tests create an unclaimed temporary pairing code; they never connect an account or write to a real library.

## Files

- `luma.py`: native screens and UI workers
- `backend.py`: Stremio protocol, library state, keyring-backed encrypted storage
- `player.py`: owned mpv process and private IPC
- `launch.sh`: desktop entry point
- `tests/test_luma.py`: automated checks

Protocol references: [Stremio add-on protocol](https://github.com/Stremio/stremio-addon-sdk/blob/master/docs/protocol.md), [linking API definitions](https://stremio.github.io/stremio-core/src/stremio_core/types/api/request.rs.html), [mpv IPC and playback options](https://mpv.io/manual/stable/).

## 0.1.1 — Live catalog correction

Live uses explicit TV/channel/sport/event categories rather than treating every custom type as live. Anime, generic download libraries, replays and highlights are excluded. The eight-catalog cutoff is removed from Live. Entering Live refreshes the account add-on list and the configured live-provider manifests without flushing pending library writes. Providers that declare live types but return no catalogs are shown with an explanation. Catalog items missing a type inherit it from their catalog so channel playback uses the right provider resource.
