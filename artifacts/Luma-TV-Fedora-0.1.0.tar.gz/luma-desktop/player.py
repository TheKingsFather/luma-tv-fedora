"""Owned mpv process with a private JSON IPC socket; URLs never enter argv."""
import json
import shutil
import socket
import subprocess
import tempfile
import time
from PyQt6.QtCore import QObject, QTimer, pyqtSignal

class Player(QObject):
    changed = pyqtSignal(float, float, bool)
    finished = pyqtSignal(bool)
    message = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.process = None
        self.socket = None
        self.folder = None
        self.buffer = b''
        self.streams = []
        self.index = 0
        self.position = self.duration = 0.
        self.paused = False
        self.resume = 0.
        self.loading = False
        self.headless = False
        self.timer = QTimer(self)
        self.timer.setInterval(100)
        self.timer.timeout.connect(self.tick)

    def start(self, streams, index=0, resume=0):
        self.stop()
        if not shutil.which('mpv'):
            raise RuntimeError('Install mpv to play video.')
        self.streams, self.index, self.resume = streams, index, resume
        self.position = self.duration = 0.
        self.folder = tempfile.TemporaryDirectory(prefix='luma-player-')
        self.path = self.folder.name + '/ipc'
        args = ['mpv', '--no-config', '--idle=yes', '--force-window=yes', '--no-terminal', '--keep-open=no', '--title=Luma TV', '--input-ipc-server=' + self.path]
        if self.headless:
            args += ['--vo=null', '--ao=null', '--force-window=no']
        self.process = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.deadline = time.monotonic() + 12
        self.timer.start()

    def send(self, *command):
        if self.socket:
            self.socket.sendall((json.dumps({'command': list(command)}) + '\n').encode())

    def load(self):
        stream = self.streams[self.index]
        headers = stream.get('behaviorHints', {}).get('proxyHeaders', {}).get('request', {})
        fields = [f'{k}: {v}' for k, v in headers.items() if '\n' not in str(k)+str(v) and '\r' not in str(k)+str(v)]
        self.send('set_property', 'http-header-fields', fields)
        self.send('loadfile', stream['url'], 'replace')
        self.loading = True
        self.deadline = time.monotonic() + 35
        self.message.emit('Opening ' + stream.get('name', stream.get('provider', 'your source')))

    def tick(self):
        if not self.process:
            return
        if self.process.poll() is not None:
            self.timer.stop()
            self.finished.emit(False)
            return
        if not self.socket:
            try:
                s = socket.socket(socket.AF_UNIX)
                s.connect(self.path)
                s.setblocking(False)
                self.socket = s
                self.buffer = b''
                for i, name in enumerate(('time-pos', 'duration', 'pause')):
                    self.send('observe_property', i, name)
                self.load()
            except (OSError, FileNotFoundError):
                s.close()
                if time.monotonic() > self.deadline:
                    self.stop()
                    self.message.emit('The player could not start. Please try again.')
                return
        try:
            while True:
                data = self.socket.recv(65536)
                if not data:
                    break
                self.buffer += data
                while b'\n' in self.buffer:
                    line, self.buffer = self.buffer.split(b'\n', 1)
                    self.handle_event(json.loads(line))
                    if not self.socket:
                        return
        except BlockingIOError:
            pass
        except (OSError, ValueError):
            return
        if self.loading and time.monotonic() > self.deadline:
            self.failover()

    def handle_event(self, event):
        if event.get('event') == 'property-change':
            name, value = event.get('name'), event.get('data')
            if name == 'time-pos' and isinstance(value, (int, float)):
                self.position = value
            elif name == 'duration' and isinstance(value, (int, float)):
                self.duration = value
            elif name == 'pause':
                self.paused = bool(value)
            self.changed.emit(self.position, self.duration, self.paused)
        elif event.get('event') == 'file-loaded':
            self.loading = False
            if self.resume:
                self.send('seek', self.resume, 'absolute')
                self.resume = 0
            self.message.emit('Playing in mpv · Space to pause · arrows to seek · F for fullscreen')
        elif event.get('event') == 'end-file':
            if event.get('reason') == 'error':
                self.failover()
            elif event.get('reason') == 'eof':
                self.finished.emit(True)

    def failover(self):
        self.loading = False
        if self.index + 1 < len(self.streams):
            self.index += 1
            self.resume = self.position
            self.load()
        else:
            self.message.emit('No source could play. Choose another source from the title page.')

    def pause(self):
        self.send('cycle', 'pause')

    def seek(self, position):
        self.send('seek', position, 'absolute')

    def stop(self):
        self.timer.stop()
        if self.socket:
            try:
                self.send('quit')
            except OSError:
                pass
            self.socket.close()
            self.socket = None
        if self.process:
            try:
                self.process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                self.process.terminate()
                try:
                    self.process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    self.process.kill()
            self.process = None
        if self.folder:
            self.folder.cleanup()
            self.folder = None
