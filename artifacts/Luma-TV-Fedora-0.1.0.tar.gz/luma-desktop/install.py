#!/usr/bin/env python3
"""Register the extracted project for the current desktop user; no root required."""
import os
import shutil
import subprocess
from pathlib import Path

root=Path(__file__).resolve().parent
data=Path(os.environ.get('XDG_DATA_HOME',Path.home()/'.local/share'))
apps=data/'applications';icons=data/'icons/hicolor/scalable/apps'
apps.mkdir(parents=True,exist_ok=True);icons.mkdir(parents=True,exist_ok=True)
launcher=root/'launch.sh';launcher.chmod(0o755)
shutil.copyfile(root/'luma.svg',icons/'tv.luma.Fedora.svg')
# Desktop Entry string escaping, not shell interpolation.
executable=str(launcher).replace('\\','\\\\').replace('"','\\"').replace('`','\\`').replace('$','\\$').replace('%','%%')
(apps/'tv.luma.Fedora.desktop').write_text('[Desktop Entry]\nType=Application\nName=Luma TV\nGenericName=Stremio media client\nComment=Your Stremio library in a glass desktop interface\nExec="'+executable+'"\nIcon=tv.luma.Fedora\nTerminal=false\nCategories=AudioVideo;Video;Player;\nKeywords=Stremio;Luma;Movies;Series;TV;\nStartupNotify=true\n')
bin_dir=Path.home()/'.local/bin';bin_dir.mkdir(parents=True,exist_ok=True)
link=bin_dir/'luma-tv'
if link.is_symlink():link.unlink()
if not link.exists():link.symlink_to(launcher)
if shutil.which('update-desktop-database'):subprocess.run(['update-desktop-database',str(apps)],check=True)
print('Installed Luma TV in your applications menu.')
