#!/usr/bin/env python3
"""Luma for Fedora: native Qt glass UI, Stremio linking and mpv playback."""
import concurrent.futures as futures
import json
import os
import sys
import time
from pathlib import Path
from urllib.parse import urlsplit

import requests
from PyQt6 import sip
from PyQt6.QtCore import Qt, QTimer, QObject, pyqtSignal, QSettings, QSize
from PyQt6.QtGui import QColor, QPainter, QLinearGradient, QRadialGradient, QPixmap, QIcon, QShortcut, QKeySequence
from PyQt6.QtWidgets import (QApplication, QMainWindow, QStackedWidget, QWidget, QFrame, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QGridLayout, QScrollArea, QLineEdit, QDialog, QComboBox, QMessageBox, QSlider, QSizePolicy)
from backend import Client, request, browseable, extra, future_video, UA, LIVE_TYPES, catalog_choices
from player import Player
from cards import MediaCard, Artwork, ResponsiveGrid
from player_view import PlaybackView

ROOT = Path(__file__).resolve().parent
POOL = futures.ThreadPoolExecutor(8)
IMAGES = futures.ThreadPoolExecutor(4)
WRITES = futures.ThreadPoolExecutor(1)

STYLE = '''
QWidget {color:#F1F7FF; font-family:"Inter","Noto Sans",sans-serif; font-size:14px;}
QMainWindow, QDialog {background:#0B1423;}
QFrame#glass {background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 rgba(99,123,151,65),stop:1 rgba(35,57,78,110)); border:1px solid rgba(224,250,255,55);border-radius:24px;}
QFrame#mediaCard {background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 rgba(99,123,151,65),stop:1 rgba(35,57,78,110));border:1px solid rgba(224,250,255,55);border-radius:20px;}
QFrame#mediaCard:hover,QFrame#mediaCard:focus {background:rgba(95,154,153,95);border:1px solid #C2F8E4;}
QPushButton {background:rgba(101,131,153,28);border:1px solid rgba(225,245,255,45);border-radius:22px;padding:11px 22px;font-weight:600;}
QPushButton:hover,QPushButton:focus {background:rgba(147,209,205,65);border:1px solid #C2F8E4;}
QPushButton:checked {background:rgba(174,225,220,45);color:#C6F9E8;border:1px solid #A6D8D4;}
QPushButton#primary {background:#C7F8E5;color:#10272C;border:1px solid #D8FFF0;}
QPushButton:disabled {color:#72869c;}
QLineEdit,QComboBox {background:rgba(62,83,108,100);border:1px solid rgba(224,250,255,65);border-radius:16px;padding:12px 18px;selection-background-color:#4A827D;}
QComboBox QAbstractItemView {background:#172A3D;color:white;selection-background-color:#3F6368;}
QScrollArea {border:0;background:transparent;}
QScrollArea > QWidget > QWidget {background:transparent;}
QScrollBar:vertical {width:7px;background:transparent;} QScrollBar::handle:vertical {background:#425A6D;border-radius:3px;min-height:30px;}
QScrollBar:horizontal {height:6px;background:transparent;} QScrollBar::handle:horizontal {background:#425A6D;border-radius:3px;}
QScrollBar::add-line,QScrollBar::sub-line {width:0;height:0;}
QToolTip {background:#213B4B;color:white;border:1px solid #789893;padding:8px;}
QSlider::groove:horizontal {height:5px;background:#3D5366;border-radius:2px;} QSlider::handle:horizontal {background:#CCF9E8;width:14px;margin:-5px 0;border-radius:7px;}
'''

class Signals(QObject):
    done = pyqtSignal(object, object, object, int)

class Ambient(QWidget):
    def __init__(self):
        super().__init__()
        self.art = None
    def paintEvent(self, event):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor('#0A1422'))
        for x,y,r,color in ((.05,.4,.9,'#163C49'),(.9,.2,.75,'#302A51'),(.6,1,.7,'#143C3D')):
            grad = QRadialGradient(self.width()*x,self.height()*y,self.width()*r)
            grad.setColorAt(0,QColor(color));grad.setColorAt(1,QColor(10,20,34,0))
            p.fillRect(self.rect(),grad)
        if self.art:
            art=self.art.scaled(self.size(),Qt.AspectRatioMode.KeepAspectRatioByExpanding,Qt.TransformationMode.SmoothTransformation)
            p.setOpacity(.6);p.drawPixmap((self.width()-art.width())//2,0,art);p.setOpacity(1)
            grad=QLinearGradient(0,0,self.width(),self.height())
            grad.setColorAt(0,QColor(7,20,32,245));grad.setColorAt(.55,QColor(7,20,32,170));grad.setColorAt(1,QColor(7,20,32,235));p.fillRect(self.rect(),grad)

def label(text,size=14,color='#F1F7FF',bold=False):
    v=QLabel(text);v.setWordWrap(True)
    v.setStyleSheet(f'font-size:{size}px;color:{color};font-weight:{600 if bold else 400};background:transparent;border:0;')
    v.setTextFormat(Qt.TextFormat.PlainText)
    return v

def button(text, callback, primary=False):
    b=QPushButton(text);b.setCursor(Qt.CursorShape.PointingHandCursor)
    if primary:b.setObjectName('primary')
    b.clicked.connect(callback)
    return b

def glass():
    f=QFrame();f.setObjectName('glass');return f

class Window(QMainWindow):
    def __init__(self, preview=False, start_live=False):
        super().__init__()
        self.setWindowTitle('Luma TV');self.setWindowIcon(QIcon(str(ROOT/'luma.svg')))
        self.resize(1360,860);self.setMinimumSize(980,700)
        self.client=Client();self.settings=QSettings('Luma','Desktop');self.generation=0
        self.bus=Signals();self.bus.done.connect(self.deliver)
        self.pair_timer=QTimer(self);self.pair_timer.setInterval(2500);self.pair_timer.timeout.connect(self.poll_pair)
        self.player=Player(self);self.player.changed.connect(self.playback_changed);self.player.finished.connect(self.playback_finished);self.player.message.connect(self.notice)
        self.play_title=None;self.play_video='';self.last_position=0;self.watched=0;self.last_sync=0;self.play_key='';self.episode_count=0
        self.playback_sync=QTimer(self);self.playback_sync.setInterval(15000);self.playback_sync.timeout.connect(self.sync_progress);self.playback_sync.start()
        self.sleep_timer=QTimer(self);self.sleep_timer.setSingleShot(True);self.sleep_timer.timeout.connect(self.player.pause)
        self.image_cache={};self.tab='Home'
        self.stack=QStackedWidget();self.setCentralWidget(self.stack);self.playback_view=None;self.root=None
        self.statusBar().setStyleSheet('color:#A2B8C9;background:#0A1422;border:0;padding:6px;')
        QShortcut(QKeySequence('F11'),self,activated=lambda:self.showNormal() if self.isFullScreen() else self.showFullScreen())
        QShortcut(QKeySequence('Escape'),self,activated=self.back)
        QShortcut(QKeySequence('Ctrl+F'),self,activated=self.search_page)
        self.page();self.layout.addWidget(label('Opening your cinema…',30),alignment=Qt.AlignmentFlag.AlignCenter)
        if preview:
            self.work(self.client.refresh,lambda _:self.home())
        else:
            self.work(self.client.restore,lambda _:self.home('Live' if start_live else 'Home') if self.client.connected else self.pair(),lambda e:(self.notice('Unlock your desktop keyring to restore your connection, or connect again.'),self.pair()))

    def work(self, func, success=lambda _:None, failure=None, token=None, pool=None):
        token=self.generation if token is None else token
        def run():
            try:result=func();error=None
            except Exception as e:result=None;error=e
            self.bus.done.emit(success,failure,(result,error),token)
        (pool or POOL).submit(run)

    def deliver(self, success, failure, result, token):
        if token>=0 and token!=self.generation:return
        value,error=result
        try:
            if error:
                if failure:failure(error)
                else:self.notice('Couldn’t complete the request. Check your connection and try again.')
            else:success(value)
        except RuntimeError:
            pass  # The owner widget can have been deleted by a screen transition.

    def page(self):
        if getattr(self,'current','')=='Playing':
            self.sync_progress();self.player.stop();self.play_title=None
        self.statusBar().show()
        self.generation+=1;self.pair_timer.stop();self.pair_code='';self.hero=None
        if self.root is not None:
            self.stack.removeWidget(self.root);self.root.deleteLater()
        root=Ambient();self.stack.addWidget(root);self.stack.setCurrentWidget(root);self.root=root
        self.layout=QVBoxLayout(root);self.layout.setContentsMargins(46,28,46,25);self.layout.setSpacing(24)
        return self.layout

    def header(self, nav=False, back=False):
        row=QHBoxLayout();brand=QHBoxLayout();mark=QLabel();mark.setPixmap(QIcon(str(ROOT/'luma.svg')).pixmap(42,42));mark.setFixedSize(42,42);brand.addWidget(mark);brand.addSpacing(5);brand.addWidget(label('luma',30,bold=True));row.addLayout(brand);row.addStretch()
        if nav:
            pane=glass();links=QHBoxLayout(pane);links.setContentsMargins(6,5,6,5);links.setSpacing(3)
            for name in ('Home','Movies','Series','Live','Library'):
                b=button(name,lambda _,n=name:self.home(n));b.setCheckable(True);b.setChecked(name==self.tab);links.addWidget(b)
            row.addWidget(pane);row.addStretch();row.addWidget(button('⌕  Search',self.search_page));row.addWidget(button('⚙',self.settings_page))
        elif back:row.addWidget(button('←  Back',self.back))
        else:
            tagline=label('YOUR STREMIO, REIMAGINED',11,'#ACBED0',True);tagline.setWordWrap(False);tagline.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter);row.addWidget(tagline)
        self.layout.addLayout(row)

    def notice(self, message):
        self.statusBar().showMessage(message,12000)
        if getattr(self,'current','')=='Playing' and self.playback_view:
            self.playback_view.show_message(message)

    def image(self, url, widget, width=250, height=360, backdrop=False):
        if not url:return
        token=self.generation
        def apply(data):
            if sip.isdeleted(widget):return
            pix=QPixmap();pix.loadFromData(data)
            if pix.isNull():return
            if backdrop:self.root.art=pix;self.root.update()
            elif isinstance(widget,Artwork):widget.setPixmap(pix)
            else:widget.setPixmap(pix.scaled(width,height,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        if url in self.image_cache:apply(self.image_cache[url]);return
        def fetch():
            if urlsplit(url).scheme not in ('http','https'):return b''
            with requests.get(url,headers={'User-Agent':UA},timeout=(8,12),stream=True) as r:
                r.raise_for_status();data=bytearray()
                for chunk in r.iter_content(65536):
                    data.extend(chunk)
                    if len(data)>12*1024*1024:raise ValueError('Image too large')
                return bytes(data)
        def done(data):
            if len(self.image_cache)>90:self.image_cache.clear()
            self.image_cache[url]=data;apply(data)
        self.work(fetch,done,lambda _:None,token,pool=POOL if backdrop else IMAGES)

    def pair(self):
        self.page();self.current='Connect';self.header()
        body=QHBoxLayout();body.setSpacing(65)
        left=QVBoxLayout();left.addStretch();left.addWidget(label('A LITTLE GLASS. A LOT OF CINEMA.',12,'#C0F4E1',True));left.addSpacing(18)
        left.addWidget(label('Everything you love.\nIn a new light.',52,bold=True));left.addSpacing(18)
        left.addWidget(label('Connect Stremio to bring your library, add-ons\nand the things you’re watching to Fedora.',18,'#AEBED1'));left.addSpacing(30)
        left.addWidget(label('01   Open your phone’s camera       02   Scan & connect',13,'#D9E8EC'));left.addSpacing(28)
        left.addWidget(button('Explore the interface  →',self.explore),alignment=Qt.AlignmentFlag.AlignLeft);left.addStretch();body.addLayout(left,3)
        panel=glass();panel.setFixedWidth(350);right=QVBoxLayout(panel);right.setContentsMargins(28,26,28,28);right.setSpacing(20)
        qr_heading=label('CONNECT WITH STREMIO',12,'#C0F4E1',True);qr_heading.setWordWrap(False);qr_heading.setFixedSize(290,26);qr_heading.setAlignment(Qt.AlignmentFlag.AlignCenter);right.addWidget(qr_heading)
        self.qr=QLabel();self.qr.setFixedSize(290,290);self.qr.setAlignment(Qt.AlignmentFlag.AlignCenter);self.qr.setStyleSheet('background:#F7FFFB;border-radius:20px;');right.addWidget(self.qr)
        self.code_label=label('· · · ·',28,bold=True);self.code_label.setAlignment(Qt.AlignmentFlag.AlignCenter);right.addWidget(self.code_label)
        self.pair_status=label('Creating your connection…',13,'#C0F4E1');self.pair_status.setAlignment(Qt.AlignmentFlag.AlignCenter);right.addWidget(self.pair_status)
        right.addWidget(button('New code',self.new_code));body.addWidget(panel,1,Qt.AlignmentFlag.AlignVCenter)
        self.layout.addLayout(body,1);self.layout.addWidget(label('Your phone handles sign-in. Or enter the code at link.stremio.com.',12,'#A2B8C9'))
        self.new_code()

    def new_code(self):
        self.pair_timer.stop();self.pair_code='';self.pair_busy=False;self.pair_serial=getattr(self,'pair_serial',0)+1;serial=self.pair_serial
        self.qr.clear();self.code_label.setText('· · · ·');self.pair_status.setText('Creating your connection…')
        def done(value):
            if serial!=self.pair_serial:return
            self.pair_code=value['code'];self.pair_started=time.monotonic();self.code_label.setText(' '.join(self.pair_code.upper()));self.pair_status.setText('●  Waiting for your phone')
            qr=value.get('qrcode','')
            if urlsplit(qr).netloc=='link.stremio.com':self.image(qr,self.qr,290,290)
            self.pair_timer.start()
        self.work(self.client.create_link,done,lambda _:self.pair_status.setText('Couldn’t connect. Select New code to retry.'))

    def poll_pair(self):
        if self.pair_busy or not self.pair_code:return
        if time.monotonic()-self.pair_started>600:self.pair_timer.stop();self.pair_status.setText('Code expired. Select New code.');return
        self.pair_busy=True;code=self.pair_code
        def done(key):
            self.pair_busy=False
            if code!=self.pair_code:return
            if key:
                self.pair_timer.stop();self.pair_status.setText('Connected. Bringing your library in…')
                self.work(lambda:self.client.connect(key),lambda _:self.home(),lambda _:self.pair_status.setText('Couldn’t save the connection. Unlock the desktop keyring, then try a new code.'))
        self.work(lambda:self.client.read_link(code),done,lambda _:(setattr(self,'pair_busy',False),self.pair_status.setText('Reconnecting…')))

    def explore(self):
        self.notice('Opening the public catalog…');self.work(self.client.refresh,lambda _:self.home())

    def scroll(self):
        sc=QScrollArea();sc.setWidgetResizable(True);content=QWidget();box=QVBoxLayout(content);box.setContentsMargins(3,6,3,15);box.setSpacing(24);sc.setWidget(content);self.layout.addWidget(sc,1);return box

    def home(self,tab='Home',live_refreshed=False):
        self.tab=tab;self.page();self.current='Home';self.header(nav=True)
        self.hero_title=label('A world worth getting lost in.',40,bold=True);self.hero_meta=label('YOUR NEXT GREAT WATCH',12,'#C0F4E1',True);self.hero_desc=label('Your films, series and favourites, together in a different light.',16,'#AEBED1');self.hero_desc.setMaximumWidth(800)
        hero=QVBoxLayout();hero.setSpacing(12);hero.addSpacing(12);hero.addWidget(self.hero_meta);hero.addWidget(self.hero_title);hero.addWidget(self.hero_desc);hero.addSpacing(10);self.layout.addLayout(hero)
        rows=self.scroll()
        if tab=='Live' and self.client.connected and not live_refreshed:
            rows.addWidget(label('Refreshing your live add-ons…',20,'#AEBED1'))
            self.work(self.client.refresh_addons,lambda _:self.home('Live',True),lambda _:(self.notice('Couldn’t refresh add-ons. Showing the saved live catalogs.'),self.home('Live',True)))
            return
        if tab=='Library':
            if not self.client.connected:rows.addWidget(label('Connect Stremio to see your saved titles.',22));rows.addWidget(button('Connect Stremio',self.pair));return
            self.add_row(rows,'Your library',self.client.library());return
        continuing=self.client.library(True)
        if continuing and tab=='Home':self.add_row(rows,'Continue watching',continuing)
        if not self.client.addons:
            self.work(self.client.refresh,lambda _:self.home(tab));return
        choices=catalog_choices(self.client.addons,tab)
        if not choices:rows.addWidget(label('No catalogs here yet. Add a compatible provider in Stremio, then refresh in Settings.',20,'#AEBED1'))
        for addon,catalog in choices:
            row_name=catalog.get('name','Catalog')+(' · '+addon.get('manifest',{}).get('name','Live add-on') if tab=='Live' else '')
            section=QWidget();box=QVBoxLayout(section);box.setContentsMargins(0,0,0,0);loading=label(row_name+' · Loading…',18);box.addWidget(loading);rows.addWidget(section)
            def loaded(items,box=box,loading=loading,addon=addon,catalog=catalog):
                loading.hide();self.add_row(box,catalog.get('name',catalog['id'])+' · '+(addon.get('manifest',{}).get('name','Live add-on') if tab=='Live' else 'Series' if catalog.get('type')=='series' else 'Movies' if catalog.get('type')=='movie' else catalog.get('type','')),items,lambda:self.catalog_page(addon,catalog))
                if items and not self.hero:self.set_hero(items[0])
            self.work(lambda a=addon,c=catalog:self.client.catalog(a,c),loaded,lambda _,w=loading,n=row_name:w.setText(n+' · Unavailable. Refresh to try again.'))
        if tab=='Live':
            for addon in self.client.addons:
                manifest=addon.get('manifest',{})
                if set(manifest.get('types') or []) & LIVE_TYPES and not manifest.get('catalogs'):
                    rows.addWidget(label(manifest.get('name','Live add-on')+' · This add-on currently publishes no catalogs. Enable its TV catalogs in the provider’s Stremio configuration, then refresh here.',15,'#AEBED1'))
        rows.addStretch();self.layout.addWidget(label('YOUR STREMIO  ·  '+('Connected as '+self.client.state['name'] if self.client.connected else 'Preview · Connect in Settings')+'                 F11  Fullscreen    Ctrl+F  Search',11,'#91A7BA'))

    def set_hero(self,title):
        self.hero=title;self.hero_title.setText(title.get('name','Untitled'));self.hero_meta.setText((title.get('type','movie').upper())+'   ·   '+str(title.get('releaseInfo','YOUR STREMIO')))
        self.hero_desc.setText(title.get('description','Choose a title, find your source and settle in.')[:300]);self.image(title.get('background',''),self.hero_title,backdrop=True)

    def add_row(self,parent,name,items,more=None):
        top=QHBoxLayout();top.addWidget(label(name,21,bold=True));top.addStretch()
        if more:top.addWidget(button('View all  →',more))
        parent.addLayout(top)
        if not items:parent.addWidget(label('Nothing here yet.',14,'#AEBED1'));return
        sc=QScrollArea();sc.setWidgetResizable(False);sc.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff);content=QWidget();cards=QHBoxLayout(content);cards.setContentsMargins(2,4,2,8);cards.setSpacing(16)
        height=0
        for title in items[:14]:
            card=self.poster(title,248 if str(title.get('type','')).lower() in LIVE_TYPES else 144);cards.addWidget(card);height=max(height,card.height())
        sc.setFixedHeight(height+30)
        content.adjustSize();sc.setWidget(content);parent.addWidget(sc)

    def poster(self,title,width=144):
        card=MediaCard(title,lambda:self.details(title),width)
        self.image(title.get('poster',''),card.art,width,card.art.height())
        return card

    def grid(self,parent,items):
        parent.addWidget(ResponsiveGrid(items,self.poster))

    def catalog_page(self,addon,catalog):
        self.page();self.current='Catalog';self.header(back=True);self.layout.addWidget(label(catalog.get('name','Catalog'),34,bold=True));rows=self.scroll()
        def load(offset=0):
            self.work(lambda:self.client.catalog(addon,catalog,offset),lambda items:render(items,offset))
        def render(items,offset):
            self.grid(rows,items)
            if items and extra(catalog,'skip'):
                more=button('Load more',lambda:(more.hide(),load(offset+len(items))));rows.addWidget(more)
        load()

    def search_page(self):
        self.page();self.current='Search';self.header(back=True);self.layout.addWidget(label('Find your next obsession.',36,bold=True));row=QHBoxLayout();field=QLineEdit();field.setPlaceholderText('Search films and series');row.addWidget(field);row.addWidget(button('Search',lambda:search()));self.layout.addLayout(row);area=self.scroll()
        def search():
            query=field.text().strip()
            if not query:return
            self.search_id=getattr(self,'search_id',0)+1;serial=self.search_id
            while area.count():
                item=area.takeAt(0)
                if item.widget():item.widget().deleteLater()
                elif item.layout():
                    layout=item.layout()
                    while layout.count():
                        child=layout.takeAt(0)
                        if child.widget():child.widget().deleteLater()
            status=label('Searching…',18,'#AEBED1');area.addWidget(status)
            def results(items):
                if serial!=self.search_id:return
                status.setText(f'{len(items)} results for “{query}”');self.grid(area,items[:80])
            self.work(lambda:self.client.search(query),results)
        field.returnPressed.connect(search);field.setFocus()

    def details(self,title,loaded=False):
        self.page();self.current='Details';self.detail=title;self.header(back=True)
        self.image(title.get('background',''),self.root,backdrop=True)
        self.layout.addWidget(label(title.get('type','movie').upper()+'   /   '+str(title.get('releaseInfo','YOUR STREMIO')),12,'#C0F4E1',True))
        self.layout.addWidget(label(title.get('name','Untitled'),44,bold=True))
        self.layout.addWidget(label('   ·   '.join(str(x) for x in [title.get('runtime'),('★ '+str(title['imdbRating'])) if title.get('imdbRating') else None]+title.get('genres',[])[:3] if x),14,'#C0F4E1'))
        description=label(title.get('description','Loading title information…' if not loaded else 'Choose a source to start watching.'),17,'#AEBED1');description.setMaximumWidth(1000);self.layout.addWidget(description)
        videos=sorted(title.get('videos',[]),key=lambda v:(v.get('season',0),v.get('episode',0)))
        ident=title.get('id',title.get('_id'));state=self.client.state['library'].get(ident,{}).get('state',{})
        video=state.get('video_id') or next((v['id'] for v in videos if v.get('season',0)>0 and not future_video(v)),ident)
        actions=QHBoxLayout();actions.addWidget(button('▶  Resume' if self.client.resume(ident,video) else '▶  Watch now',lambda:self.sources(title,video),True));actions.addWidget(button('Choose source',lambda:self.sources(title,video,choose=True)))
        if self.client.connected:
            saved=button('✓  In library' if self.client.saved(ident) else '＋  Library',lambda:self.work(lambda:self.client.toggle(title),lambda yes:saved.setText('✓  In library' if yes else '＋  Library'),pool=WRITES));actions.addWidget(saved)
        actions.addStretch();self.layout.addLayout(actions)
        if videos:
            seasons=sorted({v.get('season',0) for v in videos});selector=QComboBox()
            for season in seasons:selector.addItem(f'Season {season}' if season else 'Specials',season)
            self.layout.addWidget(selector,alignment=Qt.AlignmentFlag.AlignLeft);episodes=self.scroll()
            def populate():
                while episodes.count():
                    item=episodes.takeAt(0)
                    if item.widget():item.widget().deleteLater()
                for v in videos:
                    if v.get('season',0)!=selector.currentData():continue
                    text=f"E{v.get('episode',0)}   {v.get('title',v.get('name','Episode'))}"
                    b=button(text,lambda _,v=v:self.sources(title,v['id'],included=v.get('streams')));b.setEnabled(not future_video(v));episodes.addWidget(b)
                episodes.addStretch()
            selector.currentIndexChanged.connect(populate);selector.setCurrentIndex(seasons.index(1) if 1 in seasons else 0);populate()
        else:self.layout.addStretch();self.layout.addWidget(label('STARRING   '+'  ·  '.join(title.get('cast',[])[:6]),13,'#AEBED1'))
        if not loaded:self.work(lambda:self.client.meta(title),lambda meta:self.details(meta,True))

    def sources(self,title,video,choose=False,included=None):
        if not self.client.connected:self.pair();return
        if title.get('type')=='series' and video==title.get('id'):self.notice('Choose an episode from the list.');return
        self.notice('Finding your sources…')
        def ready(streams):
            if not streams:self.notice('No playable direct streams. Check your streaming add-ons in Stremio.');return
            if choose or self.settings.value('chooseSource',False,type=bool):
                dialog=QDialog(self);dialog.setWindowTitle('Choose your source');dialog.resize(760,500);box=QVBoxLayout(dialog);box.addWidget(label('Choose your source',28,bold=True));sc=QScrollArea();sc.setWidgetResizable(True);content=QWidget();items=QVBoxLayout(content)
                for i,s in enumerate(streams):
                    b=button(s.get('name',s.get('provider','Source'))+'\n'+s.get('description',s.get('title','')),lambda _,i=i:(dialog.accept(),self.play(title,video,streams,i)));items.addWidget(b)
                sc.setWidget(content);box.addWidget(sc);dialog.exec()
            else:self.play(title,video,streams,0)
        self.work(lambda:self.client.streams(title,video,included if included is not None else title.get('streams') if video==title.get('id') else None),ready)

    def play(self,title,video,streams,index=0,resume=None):
        self.page();self.play_title=title;self.play_video=video;self.play_key=self.client.state['key'];self.watched=0;self.last_position=0
        position=self.client.resume(title.get('id',title.get('_id')),video) if resume is None else resume
        try:
            self.player.start(streams,index,position);self.now_playing()
        except Exception:
            self.player.stop();self.play_title=None;self.notice('The embedded player could not start. Check the libmpv installation.')

    def now_playing(self):
        self.current='Playing';self.statusBar().hide()
        if self.playback_view is None:
            self.playback_view=PlaybackView(self.player,self.play_title.get('name',''),self.stop_playback,self.tracks,self.player_sources,self.next_episode,self.sleep_menu,self.toggle_fullscreen)
            self.stack.addWidget(self.playback_view)
        self.playback_view.title.setText(self.play_title.get('name',''))
        self.playback_view.show_message('Opening your source…');self.playback_view.show_controls()
        self.stack.setCurrentWidget(self.playback_view)
        self.playback_view.setFocus()

    def playback_changed(self,position,duration,paused):
        delta=position-self.last_position
        if not paused and 0<delta<3:self.watched+=delta
        self.last_position=position

    def sync_progress(self,ended=False):
        if not self.play_title or not self.play_key:return
        args=(dict(self.play_title),self.play_video,self.player.position,self.player.duration,self.watched,ended);key=self.play_key;self.watched=0
        def save():
            if key==self.client.state.get('key'):self.client.progress(*args)
        WRITES.submit(save)

    def playback_finished(self,ended):
        self.sync_progress(ended)
        if ended and self.settings.value('autoplay',True,type=bool):self.next_episode(automatic=True)
        else:self.notice('Playback finished.')

    def next_episode(self,automatic=False):
        if not self.play_title:return
        videos=sorted(self.play_title.get('videos',[]),key=lambda v:(v.get('season',0),v.get('episode',0)))
        for i,v in enumerate(videos[:-1]):
            if v['id']==self.play_video:
                next_v=videos[i+1]
                if future_video(next_v):break
                if automatic and self.episode_count>=2:
                    if QMessageBox.question(self,'Still watching?','Your next episode is ready. Keep watching?')!=QMessageBox.StandardButton.Yes:return
                    self.episode_count=0
                self.episode_count+=1;self.sources(self.play_title,next_v['id'],included=next_v.get('streams'));return
        self.notice('You’re all caught up.')

    def tracks(self):
        dialog=QDialog(self);dialog.setWindowTitle('Audio & subtitles');dialog.resize(560,380);box=QVBoxLayout(dialog);box.addWidget(label('Audio & subtitles',26,bold=True))
        for kind,prop,heading in [('audio','aid','Audio track'),('sub','sid','Subtitles')]:
            box.addWidget(label(heading,15,'#C0F4E1',True));choices=QComboBox();choices.addItem('Automatic' if kind=='audio' else 'Off','auto' if kind=='audio' else 'no')
            for track in self.player.tracks:
                if track.get('type')!=kind:continue
                name=track.get('title') or track.get('lang') or f'Track {track["id"]}'
                choices.addItem(name+' · '+str(track.get('codec','')),track['id'])
                if track.get('selected'):choices.setCurrentIndex(choices.count()-1)
            choices.currentIndexChanged.connect(lambda _,c=choices,p=prop:self.player.send('set_property',p,c.currentData()));box.addWidget(choices)
        def found(subtitles):
            for sub in subtitles[:30]:box.addWidget(button(sub.get('lang','Subtitle')+' · '+str(sub.get('id','')),lambda _,s=sub:self.external_subtitle(s)))
        if self.play_title:self.work(lambda:self.client.subtitles(self.play_title,self.play_video),found)
        dialog.exec()

    def external_subtitle(self,sub):
        folder=self.player.folder
        if not folder:return
        path=Path(folder.name)/'subtitle.srt'
        def download():
            # Never reuse video-provider headers for subtitle hosts.
            with requests.get(sub['url'],headers={'User-Agent':UA},timeout=15,stream=True) as r:
                r.raise_for_status();data=bytearray()
                for chunk in r.iter_content(65536):
                    data.extend(chunk)
                    if len(data)>5*1024*1024:raise ValueError('Subtitle too large')
            path.write_bytes(data)
        self.work(download,lambda _:self.player.send('sub-add',str(path),'select'))

    def sleep_menu(self):
        dialog=QDialog(self);dialog.setWindowTitle('Sleep timer');box=QVBoxLayout(dialog)
        for name,minutes in [('Off',0),('In 30 minutes',30),('In 60 minutes',60)]:box.addWidget(button(name,lambda _,m=minutes:(self.sleep_timer.stop(),self.sleep_timer.start(m*60000) if m else None,dialog.accept())))
        dialog.exec()

    def stop_playback(self):
        title=self.play_title
        if self.isFullScreen():self.showNormal()
        self.statusBar().show()
        if title:self.details(title,True)
        else:self.home(self.tab)

    def player_sources(self):
        streams=list(self.player.streams);dialog=QDialog(self);dialog.setWindowTitle('Choose source');box=QVBoxLayout(dialog)
        for i,stream in enumerate(streams):
            def select(_,index=i):
                title,video,position=self.play_title,self.play_video,self.player.position
                dialog.accept();self.play(title,video,streams,index,position)
            box.addWidget(button(stream.get('name',stream.get('provider','Source')),select))
        dialog.exec()

    def toggle_fullscreen(self):
        if self.isFullScreen():self.showNormal()
        else:self.showFullScreen()

    def keyPressEvent(self,event):
        if getattr(self,'current','')=='Playing':
            key=event.key()
            if key==Qt.Key.Key_Space:self.player.pause()
            elif key in (Qt.Key.Key_Left,Qt.Key.Key_Right):self.player.seek(self.player.position+(-10 if key==Qt.Key.Key_Left else 10))
            elif key==Qt.Key.Key_F:self.toggle_fullscreen()
            elif key==Qt.Key.Key_M:self.player.send('cycle','mute')
            else:return super().keyPressEvent(event)
            self.playback_view.show_controls();event.accept();return
        super().keyPressEvent(event)

    def settings_page(self):
        self.page();self.current='Settings';self.header(back=True);self.layout.addWidget(label('Make yourself at home.',36,bold=True))
        panel=glass();box=QVBoxLayout(panel);box.setContentsMargins(28,25,28,25);box.setSpacing(20)
        box.addWidget(label('YOUR STREMIO',12,'#C0F4E1',True));box.addWidget(label(self.client.state['name'] if self.client.connected else 'A cinema with your name on it.',26,bold=True));box.addWidget(label(f'{len(self.client.addons)} add-ons · Library sync enabled' if self.client.connected else 'Scan a code to connect your library and add-ons.',15,'#AEBED1'))
        box.addWidget(button('Refresh Stremio' if self.client.connected else 'Connect Stremio',lambda:self.work(self.client.refresh,lambda _:self.settings_page()) if self.client.connected else self.pair(),True))
        if self.client.connected:box.addWidget(button('Disconnect this desktop',self.disconnect))
        for key,name,default in [('chooseSource','Always choose a source',False),('autoplay','Play the next episode',True)]:
            enabled=self.settings.value(key,default,type=bool);b=button(name+('  ·  On' if enabled else '  ·  Off'),lambda _,k=key,e=enabled:(self.settings.setValue(k,not e),self.settings_page()));box.addWidget(b)
        box.addWidget(label('Manage add-ons in Stremio on your phone, then refresh them here.',13,'#AEBED1'));self.layout.addWidget(panel);self.layout.addStretch();self.layout.addWidget(label('Luma TV for Fedora  0.2.0    ·    F11 fullscreen    ·    Playback powered by mpv',12,'#A2B8C9'))

    def disconnect(self):
        if QMessageBox.question(self,'Disconnect Stremio?','Remove this desktop’s saved account connection?')!=QMessageBox.StandardButton.Yes:return
        self.sync_progress();self.player.stop();self.play_title=None
        self.work(self.client.disconnect,lambda _:self.pair(),pool=WRITES)

    def back(self):
        if self.isFullScreen():self.showNormal()
        elif getattr(self,'current','')=='Playing':self.stop_playback()
        elif self.client.addons:self.home(self.tab)
        else:self.pair()

    def closeEvent(self,event):
        self.generation+=1;self.pair_timer.stop();self.sync_progress();self.player.shutdown();self.playback_sync.stop();event.accept()

def main():
    app=QApplication(sys.argv);app.setApplicationName('tv.luma.Fedora');app.setApplicationDisplayName('Luma TV');app.setDesktopFileName('tv.luma.Fedora');app.setWindowIcon(QIcon(str(ROOT/'luma.svg')));app.setOrganizationName('Luma');app.setStyle('Fusion');app.setStyleSheet(STYLE)
    window=Window('--preview' in sys.argv,'--live' in sys.argv);window.show()
    if '--smoke' in sys.argv:
        def capture():
            window.grab().save(str(ROOT/'artifacts/desktop.png'));window.close();app.quit()
        QTimer.singleShot(12000,capture)
    result=app.exec()
    POOL.shutdown(wait=False,cancel_futures=True)
    IMAGES.shutdown(wait=False,cancel_futures=True)
    WRITES.shutdown(wait=True)
    return result

if __name__=='__main__':
    sys.exit(main())
